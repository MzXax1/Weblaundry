<?php 
	require_once('../_header.php');
	$dc_number = $_GET['or_dc_number'];
?>

<?php if (del_or_dc($dc_number) > 0) : ?>
	<!-- Statement 1 -->
	<div class="alert">
		<div class="box">
		<img src="../_assets/img/berhasil.png" height="68" alt="alert sukses">
			<p>Data Berhasil Di Hapus</p>
			<button onclick="goBack()" class="btn-alert">Ok</button>
		</div>
	</div>
	<?php else : ?>
		<!-- Statement 2 -->
		<div class="alert">
			<div class="box">
			<img src="../_assets/img/gagal.png" height="68" alt="alert gagal">
				<p>Data Gagal Di Hapus</p>
				<button onclick="goBack()" class="btn-alert">Ok</button>
			</div>
		</div>
<?php endif ?>
<script>
  function goBack(){
    window.history.back();
  }
  
</script>